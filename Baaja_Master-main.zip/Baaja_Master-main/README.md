# Baaja
Its a music player, My own style music player.
Developed in JAVA, used JLayer(javazoom) library for playing mp3.

I have added output of this project. Check That out.
Peace.

# Setup
visit https://www.youtube.com/watch?v=dA7g4ELUOrw&t=5s 

## Output :
![alt Output1](https://raw.githubusercontent.com/roshansourav/Baaja/master/Screenshots/Screenshot%20from%202020-06-20%2011-45-12.png)

![alt Output2](https://raw.githubusercontent.com/roshansourav/Baaja/master/Screenshots/Screenshot%20from%202020-06-20%2011-45-29.png)

![alt Output3](https://raw.githubusercontent.com/roshansourav/Baaja/master/Screenshots/Screenshot%20from%202020-06-20%2011-45-35.png)

![alt Output4](https://raw.githubusercontent.com/roshansourav/Baaja/master/Screenshots/Screenshot%20from%202020-06-20%2011-45-38.png)

![alt Output5](https://raw.githubusercontent.com/roshansourav/Baaja/master/Screenshots/Screenshot%20from%202020-06-20%2011-45-41.png)

![alt Output6](https://raw.githubusercontent.com/roshansourav/Baaja/master/Screenshots/Screenshot%20from%202020-06-20%2011-45-44.png)

![alt Output7](https://raw.githubusercontent.com/roshansourav/Baaja/master/Screenshots/Screenshot%20from%202020-06-20%2011-45-47.png)

![alt Output8](https://raw.githubusercontent.com/roshansourav/Baaja/master/Screenshots/Screenshot%20from%202020-06-20%2011-45-50.png)

![alt Output9](https://raw.githubusercontent.com/roshansourav/Baaja/master/Screenshots/Screenshot%20from%202020-06-20%2011-45-58.png)
